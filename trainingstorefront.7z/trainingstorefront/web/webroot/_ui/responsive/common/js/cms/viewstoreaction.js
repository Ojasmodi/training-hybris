ACC.viewstoreaction = {

}

$(document).ready(function ()
{

});
